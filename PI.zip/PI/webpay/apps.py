from django.apps import AppConfig


class WebpayConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'webpay'
    verbose_name = 'WebPay (Transbank Sandbox)'